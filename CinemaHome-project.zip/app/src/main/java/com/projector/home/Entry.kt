package com.projector.home

import android.content.Intent
import android.graphics.drawable.Drawable

/** One launchable app shown in a row. */
data class Entry(
    val label: String,
    val icon: Drawable,
    val intent: Intent,
    val pkg: String
)
