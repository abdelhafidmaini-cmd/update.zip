package com.projector.home

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.doOnLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("home", Context.MODE_PRIVATE) }
    private val cm by lazy { getSystemService(ConnectivityManager::class.java) }

    private lateinit var scroll: ScrollView
    private lateinit var greeting: TextView
    private lateinit var netDot: View
    private lateinit var netText: TextView
    private lateinit var favSection: View
    private lateinit var favRow: RecyclerView
    private lateinit var appRow: RecyclerView
    private lateinit var favAdapter: EntryAdapter
    private lateinit var appAdapter: EntryAdapter

    private var allApps: List<Entry> = emptyList()
    private var favoritePackages: MutableList<String> = mutableListOf()
    private var firstLoad = true

    // ---- Receivers ---------------------------------------------------------

    private val tickReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            updateGreeting()
        }
    }

    private val reloadAppsTask = Runnable { loadApps() }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            // Install/replace fire several broadcasts in a row: debounce
            ui.removeCallbacks(reloadAppsTask)
            ui.postDelayed(reloadAppsTask, 600)
        }
    }

    private val netCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            runOnUiThread { updateNet() }
        }

        override fun onLost(network: Network) {
            runOnUiThread { updateNet() }
        }

        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            runOnUiThread { updateNet() }
        }
    }

    // ---- Lifecycle ---------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        scroll = findViewById(R.id.scroll)
        greeting = findViewById(R.id.greeting)
        netDot = findViewById(R.id.netDot)
        netText = findViewById(R.id.netText)
        favSection = findViewById(R.id.favSection)
        favRow = findViewById(R.id.favRow)
        appRow = findViewById(R.id.appRow)

        favAdapter = EntryAdapter(
            onOpen = { open(it) },
            onToggleFavorite = { toggleFavorite(it) },
            isFavorite = { isFavorite(it) }
        )
        appAdapter = EntryAdapter(
            onOpen = { open(it) },
            onToggleFavorite = { toggleFavorite(it) },
            isFavorite = { isFavorite(it) }
        )

        setupRow(favRow, favAdapter)
        setupRow(appRow, appAdapter)

        bindQuick(R.id.btnWifi, Settings.ACTION_WIFI_SETTINGS)
        bindQuick(R.id.btnBluetooth, Settings.ACTION_BLUETOOTH_SETTINGS)
        bindQuick(R.id.btnDisplay, Settings.ACTION_DISPLAY_SETTINGS)
        bindQuick(R.id.btnSound, Settings.ACTION_SOUND_SETTINGS)
        bindQuick(R.id.btnSettings, Settings.ACTION_SETTINGS)

        loadFavorites()
        updateGreeting()
        updateNet()
        loadApps()
    }

    override fun onStart() {
        super.onStart()

        registerReceiver(tickReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
        })

        registerReceiver(packageReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        })

        try {
            cm.registerDefaultNetworkCallback(netCallback)
        } catch (e: Exception) {
            // Network state is cosmetic; ignore failures
        }

        updateGreeting()
        updateNet()
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(tickReceiver) } catch (e: IllegalArgumentException) { }
        try { unregisterReceiver(packageReceiver) } catch (e: IllegalArgumentException) { }
        try { cm.unregisterNetworkCallback(netCallback) } catch (e: Exception) { }
        ui.removeCallbacks(reloadAppsTask)
    }

    override fun onDestroy() {
        super.onDestroy()
        worker.shutdown()
    }

    // Pressing Home while we are already on top: jump back to the start
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.hasCategory(Intent.CATEGORY_HOME) == true) {
            scroll.smoothScrollTo(0, 0)
            favRow.scrollToPosition(0)
            appRow.scrollToPosition(0)
            focusFirst()
        }
    }

    // A launcher must never "exit"
    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        scroll.smoothScrollTo(0, 0)
        focusFirst()
    }

    // ---- UI setup ----------------------------------------------------------

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
    }

    private fun setupRow(row: RecyclerView, adapter: EntryAdapter) {
        row.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        row.itemAnimator = null // saves CPU on a 1 GB device and keeps focus stable
        row.adapter = adapter
    }

    private fun bindQuick(id: Int, action: String) {
        val button = findViewById<View>(id)
        button.setOnClickListener { launchSettings(action) }
        button.setOnFocusChangeListener { v, hasFocus -> FocusFx.apply(v, hasFocus) }
    }

    private fun launchSettings(action: String) {
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e2: Exception) {
                Toast.makeText(this, getString(R.string.cant_open), Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---- Header: greeting, date, network ----------------------------------

    private fun updateGreeting() {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val hello = getString(
            when {
                hour < 5 -> R.string.g_night
                hour < 12 -> R.string.g_morning
                hour < 17 -> R.string.g_day
                hour < 21 -> R.string.g_evening
                else -> R.string.g_late
            }
        )
        val date = SimpleDateFormat("EEEE d MMMM", Locale("ar", "DZ")).format(Date())
        greeting.text = "$hello  •  $date"
    }

    private fun updateNet() {
        val caps = try {
            cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
        } catch (e: Exception) {
            null
        }

        val textRes: Int
        val color: Int
        if (caps == null || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
            textRes = R.string.net_none
            color = getColor(R.color.bad)
        } else {
            color = getColor(R.color.ok)
            textRes = when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> R.string.net_wifi
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> R.string.net_eth
                else -> R.string.net_online
            }
        }

        netText.setText(textRes)
        netDot.background.mutate().setTint(color)
    }

    // ---- Apps --------------------------------------------------------------

    private fun loadApps() {
        worker.execute {
            val pm = packageManager
            val found = LinkedHashMap<String, Entry>()

            for (category in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
                val query = Intent(Intent.ACTION_MAIN).addCategory(category)
                for (info in pm.queryIntentActivities(query, 0)) {
                    val pkg = info.activityInfo.packageName
                    if (pkg == packageName || found.containsKey(pkg)) continue

                    val launch = Intent(Intent.ACTION_MAIN)
                        .addCategory(category)
                        .setClassName(pkg, info.activityInfo.name)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)

                    found[pkg] = Entry(
                        label = info.loadLabel(pm).toString(),
                        icon = info.loadIcon(pm),
                        intent = launch,
                        pkg = pkg
                    )
                }
            }

            val sorted = found.values.sortedBy { it.label.lowercase() }

            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                allApps = sorted
                renderRows()
                if (firstLoad) {
                    firstLoad = false
                    focusFirst()
                }
            }
        }
    }

    private fun renderRows() {
        val favs = favoritePackages.mapNotNull { pkg -> allApps.firstOrNull { it.pkg == pkg } }
        favAdapter.submit(favs)
        appAdapter.submit(allApps)
        favSection.visibility = if (favs.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun open(entry: Entry) {
        try {
            startActivity(entry.intent)
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.cant_open), Toast.LENGTH_SHORT).show()
        }
    }

    // ---- Favorites ---------------------------------------------------------

    private fun isFavorite(entry: Entry): Boolean = favoritePackages.contains(entry.pkg)

    private fun loadFavorites() {
        favoritePackages = (prefs.getString("favs", "") ?: "")
            .split(",")
            .filter { it.isNotBlank() }
            .toMutableList()
    }

    private fun saveFavorites() {
        prefs.edit().putString("favs", favoritePackages.joinToString(",")).apply()
    }

    private fun toggleFavorite(entry: Entry) {
        val cameFromFavorites = favRow.hasFocus()

        val added = if (favoritePackages.remove(entry.pkg)) {
            false
        } else {
            favoritePackages.add(entry.pkg)
            true
        }
        saveFavorites()

        Toast.makeText(
            this,
            getString(if (added) R.string.fav_added else R.string.fav_removed),
            Toast.LENGTH_SHORT
        ).show()

        // Update the star on the app tile in place (keeps focus), rebuild the favorites row
        val idx = appAdapter.positionOf(entry.pkg)
        if (idx >= 0) appAdapter.notifyItemChanged(idx)

        val favs = favoritePackages.mapNotNull { pkg -> allApps.firstOrNull { it.pkg == pkg } }
        favAdapter.submit(favs)
        favSection.visibility = if (favs.isEmpty()) View.GONE else View.VISIBLE

        // The tile the user was on disappeared: send focus back to the same app below
        if (cameFromFavorites && idx >= 0) {
            appRow.scrollToPosition(idx)
            appRow.doOnLayout {
                appRow.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus()
            }
        }
    }

    // ---- Focus -------------------------------------------------------------

    private fun focusFirst() {
        val row = if (favSection.visibility == View.VISIBLE) favRow else appRow
        row.doOnLayout {
            val first = row.findViewHolderForAdapterPosition(0)?.itemView
            if (first != null) first.requestFocus() else row.requestFocus()
        }
    }
}
