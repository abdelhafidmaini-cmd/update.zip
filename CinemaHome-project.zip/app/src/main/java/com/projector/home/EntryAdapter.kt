package com.projector.home

import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** Focus effect shared by every focusable tile: gentle zoom + lift above neighbours. */
object FocusFx {
    fun apply(v: View, hasFocus: Boolean) {
        val s = if (hasFocus) 1.08f else 1f
        v.animate()
            .scaleX(s)
            .scaleY(s)
            .translationZ(if (hasFocus) 12f else 0f)
            .setDuration(130)
            .start()
    }
}

class EntryAdapter(
    private val onOpen: (Entry) -> Unit,
    private val onToggleFavorite: (Entry) -> Unit,
    private val isFavorite: (Entry) -> Boolean
) : RecyclerView.Adapter<EntryAdapter.VH>() {

    private var items: List<Entry> = emptyList()

    fun submit(list: List<Entry>) {
        items = list
        notifyDataSetChanged()
    }

    fun positionOf(pkg: String): Int = items.indexOfFirst { it.pkg == pkg }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.icon)
        val label: TextView = view.findViewById(R.id.label)
        val star: ImageView = view.findViewById(R.id.star)
    }

    private fun entryAt(holder: VH): Entry? {
        val p = holder.bindingAdapterPosition
        return if (p != RecyclerView.NO_POSITION) items[p] else null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        val holder = VH(view)

        view.setOnClickListener { entryAt(holder)?.let { onOpen(it) } }

        view.setOnLongClickListener {
            entryAt(holder)?.let { onToggleFavorite(it) }
            true
        }

        // Remote "Menu" key also toggles favorite
        view.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_MENU && event.action == KeyEvent.ACTION_UP) {
                entryAt(holder)?.let { onToggleFavorite(it) }
                true
            } else {
                false
            }
        }

        view.setOnFocusChangeListener { v, hasFocus -> FocusFx.apply(v, hasFocus) }
        return holder
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = items[position]
        // Fresh drawable per tile so the same icon can live in two rows safely
        holder.icon.setImageDrawable(e.icon.constantState?.newDrawable()?.mutate() ?: e.icon)
        holder.label.text = e.label
        holder.star.visibility = if (isFavorite(e)) View.VISIBLE else View.GONE
    }

    override fun getItemCount(): Int = items.size
}
